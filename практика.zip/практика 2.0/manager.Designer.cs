﻿namespace практика_2._0
{
    partial class manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage3 = new TabPage();
            tabPage2 = new TabPage();
            tabPage1 = new TabPage();
            label1 = new Label();
            tabControl2 = new TabControl();
            tabPage5 = new TabPage();
            dateTimePicker1 = new DateTimePicker();
            textBox1 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label5 = new Label();
            label6 = new Label();
            panel10 = new Panel();
            button10 = new Button();
            button11 = new Button();
            зал = new TabPage();
            panel1 = new Panel();
            button1 = new Button();
            panel2 = new Panel();
            button7 = new Button();
            panel3 = new Panel();
            button8 = new Button();
            panel4 = new Panel();
            button9 = new Button();
            panel5 = new Panel();
            button6 = new Button();
            panel6 = new Panel();
            button5 = new Button();
            panel7 = new Panel();
            button2 = new Button();
            panel8 = new Panel();
            button3 = new Button();
            panel9 = new Panel();
            button4 = new Button();
            button12 = new Button();
            tabControl1 = new TabControl();
            tabPage1.SuspendLayout();
            tabControl2.SuspendLayout();
            tabPage5.SuspendLayout();
            panel10.SuspendLayout();
            зал.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel6.SuspendLayout();
            panel7.SuspendLayout();
            panel8.SuspendLayout();
            panel9.SuspendLayout();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage3
            // 
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(1444, 687);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Бронь";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(1444, 687);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Бронь";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.Black;
            tabPage1.Controls.Add(button12);
            tabPage1.Controls.Add(tabControl2);
            tabPage1.Controls.Add(label1);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(1444, 687);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Бронирование столов";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ForeColor = SystemColors.ButtonHighlight;
            label1.Location = new Point(520, 3);
            label1.Name = "label1";
            label1.Size = new Size(334, 41);
            label1.TabIndex = 0;
            label1.Text = "Бронирование столов";
            // 
            // tabControl2
            // 
            tabControl2.Controls.Add(зал);
            tabControl2.Controls.Add(tabPage5);
            tabControl2.Location = new Point(6, 47);
            tabControl2.Name = "tabControl2";
            tabControl2.SelectedIndex = 0;
            tabControl2.Size = new Size(1422, 631);
            tabControl2.TabIndex = 1;
            tabControl2.SelectedIndexChanged += tabControl2_SelectedIndexChanged;
            // 
            // tabPage5
            // 
            tabPage5.BackColor = Color.Silver;
            tabPage5.Controls.Add(button11);
            tabPage5.Controls.Add(panel10);
            tabPage5.Controls.Add(label6);
            tabPage5.Controls.Add(label5);
            tabPage5.Controls.Add(textBox3);
            tabPage5.Controls.Add(textBox2);
            tabPage5.Controls.Add(label3);
            tabPage5.Controls.Add(label2);
            tabPage5.Controls.Add(textBox1);
            tabPage5.Controls.Add(dateTimePicker1);
            tabPage5.Location = new Point(4, 29);
            tabPage5.Name = "tabPage5";
            tabPage5.Padding = new Padding(3);
            tabPage5.Size = new Size(1414, 598);
            tabPage5.TabIndex = 1;
            tabPage5.Text = "Бронирование";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(142, 30);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 0;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(142, 80);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(250, 27);
            textBox1.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(6, 30);
            label2.Name = "label2";
            label2.Size = new Size(102, 23);
            label2.TabIndex = 3;
            label2.Text = "Дата брони";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(6, 80);
            label3.Name = "label3";
            label3.Size = new Size(122, 23);
            label3.TabIndex = 4;
            label3.Text = "Кол-во гостей";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(142, 147);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(250, 27);
            textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(142, 234);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(250, 202);
            textBox3.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.Location = new Point(6, 147);
            label5.Name = "label5";
            label5.Size = new Size(107, 23);
            label5.TabIndex = 8;
            label5.Text = "Поедоплата";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.Location = new Point(3, 235);
            label6.Name = "label6";
            label6.Size = new Size(113, 23);
            label6.TabIndex = 9;
            label6.Text = "Примечание";
            // 
            // panel10
            // 
            panel10.BackColor = Color.Black;
            panel10.Controls.Add(button10);
            panel10.Location = new Point(3, 546);
            panel10.Name = "panel10";
            panel10.Size = new Size(250, 46);
            panel10.TabIndex = 10;
            // 
            // button10
            // 
            button10.BackColor = Color.Silver;
            button10.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button10.Location = new Point(3, 3);
            button10.Name = "button10";
            button10.Size = new Size(244, 40);
            button10.TabIndex = 11;
            button10.Text = "забронировать зал";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button11.Location = new Point(1359, 544);
            button11.Name = "button11";
            button11.Size = new Size(52, 51);
            button11.TabIndex = 11;
            button11.Text = "х";
            button11.UseVisualStyleBackColor = true;
            // 
            // зал
            // 
            зал.BackColor = Color.Silver;
            зал.Controls.Add(panel9);
            зал.Controls.Add(panel8);
            зал.Controls.Add(panel7);
            зал.Controls.Add(panel6);
            зал.Controls.Add(panel5);
            зал.Controls.Add(panel4);
            зал.Controls.Add(panel3);
            зал.Controls.Add(panel2);
            зал.Controls.Add(panel1);
            зал.ForeColor = Color.Silver;
            зал.Location = new Point(4, 29);
            зал.Name = "зал";
            зал.Padding = new Padding(3);
            зал.Size = new Size(1414, 598);
            зал.TabIndex = 0;
            зал.Text = "Смеха столов";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(button1);
            panel1.Location = new Point(189, 61);
            panel1.Name = "panel1";
            panel1.Size = new Size(99, 96);
            panel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(192, 255, 192);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(4, 3);
            button1.Name = "button1";
            button1.Size = new Size(92, 90);
            button1.TabIndex = 0;
            button1.Text = "стол 1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.Controls.Add(button7);
            panel2.Location = new Point(189, 205);
            panel2.Name = "panel2";
            panel2.Size = new Size(99, 96);
            panel2.TabIndex = 1;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(192, 255, 192);
            button7.ForeColor = Color.Black;
            button7.Location = new Point(4, 3);
            button7.Name = "button7";
            button7.Size = new Size(92, 90);
            button7.TabIndex = 14;
            button7.Text = "стол 4";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.Controls.Add(button8);
            panel3.Location = new Point(523, 61);
            panel3.Name = "panel3";
            panel3.Size = new Size(99, 96);
            panel3.TabIndex = 2;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(192, 255, 192);
            button8.ForeColor = Color.Black;
            button8.Location = new Point(3, 3);
            button8.Name = "button8";
            button8.Size = new Size(92, 90);
            button8.TabIndex = 15;
            button8.Text = "стол 3";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.Controls.Add(button9);
            panel4.Location = new Point(357, 61);
            panel4.Name = "panel4";
            panel4.Size = new Size(99, 96);
            panel4.TabIndex = 3;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(192, 255, 192);
            button9.ForeColor = Color.Black;
            button9.Location = new Point(3, 3);
            button9.Name = "button9";
            button9.Size = new Size(92, 90);
            button9.TabIndex = 16;
            button9.Text = "стол 2";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Black;
            panel5.Controls.Add(button6);
            panel5.Location = new Point(357, 205);
            panel5.Name = "panel5";
            panel5.Size = new Size(99, 96);
            panel5.TabIndex = 4;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(192, 255, 192);
            button6.ForeColor = Color.Black;
            button6.Location = new Point(4, 3);
            button6.Name = "button6";
            button6.Size = new Size(92, 90);
            button6.TabIndex = 13;
            button6.Text = "стол 5";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Black;
            panel6.Controls.Add(button5);
            panel6.Location = new Point(523, 205);
            panel6.Name = "panel6";
            panel6.Size = new Size(99, 96);
            panel6.TabIndex = 5;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(192, 255, 192);
            button5.ForeColor = Color.Black;
            button5.Location = new Point(3, 3);
            button5.Name = "button5";
            button5.Size = new Size(92, 90);
            button5.TabIndex = 12;
            button5.Text = "стол 6";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Black;
            panel7.Controls.Add(button2);
            panel7.Location = new Point(523, 345);
            panel7.Name = "panel7";
            panel7.Size = new Size(99, 96);
            panel7.TabIndex = 6;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(192, 255, 192);
            button2.ForeColor = Color.Black;
            button2.Location = new Point(3, 3);
            button2.Name = "button2";
            button2.Size = new Size(92, 90);
            button2.TabIndex = 9;
            button2.Text = "стол 9";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Black;
            panel8.Controls.Add(button3);
            panel8.Location = new Point(357, 345);
            panel8.Name = "panel8";
            panel8.Size = new Size(99, 96);
            panel8.TabIndex = 7;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(192, 255, 192);
            button3.ForeColor = Color.Black;
            button3.Location = new Point(4, 3);
            button3.Name = "button3";
            button3.Size = new Size(92, 90);
            button3.TabIndex = 10;
            button3.Text = "стол 8";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Black;
            panel9.Controls.Add(button4);
            panel9.Location = new Point(189, 345);
            panel9.Name = "panel9";
            panel9.Size = new Size(99, 96);
            panel9.TabIndex = 8;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(192, 255, 192);
            button4.ForeColor = Color.Black;
            button4.Location = new Point(4, 3);
            button4.Name = "button4";
            button4.Size = new Size(92, 90);
            button4.TabIndex = 11;
            button4.Text = "стол 7";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button12
            // 
            button12.BackColor = Color.Black;
            button12.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button12.ForeColor = SystemColors.Control;
            button12.Location = new Point(1194, 7);
            button12.Name = "button12";
            button12.Size = new Size(244, 46);
            button12.TabIndex = 2;
            button12.Text = "отчет по смене";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(2, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1452, 720);
            tabControl1.TabIndex = 0;
            // 
            // manager
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1466, 731);
            Controls.Add(tabControl1);
            Name = "manager";
            Text = "manager";
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabControl2.ResumeLayout(false);
            tabPage5.ResumeLayout(false);
            tabPage5.PerformLayout();
            panel10.ResumeLayout(false);
            зал.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel6.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel8.ResumeLayout(false);
            panel9.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabPage3;
        private TabPage tabPage2;
        private TabPage tabPage1;
        private Button button12;
        private TabControl tabControl2;
        private TabPage зал;
        private Panel panel9;
        private Button button4;
        private Panel panel8;
        private Button button3;
        private Panel panel7;
        private Button button2;
        private Panel panel6;
        private Button button5;
        private Panel panel5;
        private Button button6;
        private Panel panel4;
        private Button button9;
        private Panel panel3;
        private Button button8;
        private Panel panel2;
        private Button button7;
        private Panel panel1;
        private Button button1;
        private TabPage tabPage5;
        private Button button11;
        private Panel panel10;
        private Button button10;
        private Label label6;
        private Label label5;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label3;
        private Label label2;
        private TextBox textBox1;
        private DateTimePicker dateTimePicker1;
        private Label label1;
        private TabControl tabControl1;
    }
}
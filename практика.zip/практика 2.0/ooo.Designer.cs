﻿namespace практика_2._0
{
    partial class report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            button2 = new Button();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label5 = new Label();
            button1 = new Button();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.Silver;
            panel2.Controls.Add(button2);
            panel2.Location = new Point(222, 668);
            panel2.Name = "panel2";
            panel2.Size = new Size(75, 69);
            panel2.TabIndex = 22;
            // 
            // button2
            // 
            button2.BackColor = Color.Black;
            button2.Font = new Font("Segoe UI", 25.8000011F, FontStyle.Regular, GraphicsUnit.Point, 204);
            button2.ForeColor = SystemColors.ButtonHighlight;
            button2.Location = new Point(3, 6);
            button2.Name = "button2";
            button2.Size = new Size(69, 63);
            button2.TabIndex = 10;
            button2.Text = "х";
            button2.UseVisualStyleBackColor = false;
            // 
            // textBox6
            // 
            textBox6.BackColor = SystemColors.InfoText;
            textBox6.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox6.ForeColor = SystemColors.Info;
            textBox6.Location = new Point(106, 204);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 31);
            textBox6.TabIndex = 21;
            // 
            // textBox5
            // 
            textBox5.BackColor = SystemColors.InfoText;
            textBox5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox5.ForeColor = SystemColors.MenuBar;
            textBox5.Location = new Point(183, 167);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 20;
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.InfoText;
            textBox4.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox4.Location = new Point(224, 122);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 31);
            textBox4.TabIndex = 19;
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.InfoText;
            textBox3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            textBox3.ForeColor = SystemColors.Menu;
            textBox3.Location = new Point(194, 85);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 31);
            textBox3.TabIndex = 18;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label9.ForeColor = SystemColors.ButtonHighlight;
            label9.Location = new Point(15, 204);
            label9.Name = "label9";
            label9.Size = new Size(85, 25);
            label9.TabIndex = 17;
            label9.Text = "Выручка";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label8.ForeColor = SystemColors.ButtonHighlight;
            label8.Location = new Point(15, 124);
            label8.Name = "label8";
            label8.Size = new Size(203, 25);
            label8.TabIndex = 16;
            label8.Text = "Оплачено наличными";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label7.ForeColor = SystemColors.ButtonHighlight;
            label7.Location = new Point(15, 166);
            label7.Name = "label7";
            label7.Size = new Size(162, 25);
            label7.TabIndex = 15;
            label7.Text = "Оплачено картой";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.ForeColor = SystemColors.ButtonHighlight;
            label6.Location = new Point(12, 87);
            label6.Name = "label6";
            label6.Size = new Size(163, 25);
            label6.TabIndex = 14;
            label6.Text = "Наличных в кассе";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarForeColor = Color.Silver;
            dateTimePicker1.CalendarMonthBackground = Color.Silver;
            dateTimePicker1.Location = new Point(84, 43);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(167, 27);
            dateTimePicker1.TabIndex = 13;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(12, 43);
            label5.Name = "label5";
            label5.Size = new Size(66, 25);
            label5.TabIndex = 12;
            label5.Text = "Смена";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button1.Location = new Point(6, 409);
            button1.Name = "button1";
            button1.Size = new Size(29, 29);
            button1.TabIndex = 23;
            button1.Text = "x";
            button1.UseVisualStyleBackColor = true;
            // 
            // report
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(panel2);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(dateTimePicker1);
            Controls.Add(label5);
            Name = "report";
            Text = "report";
            Load += ooo_Load;
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel2;
        private Button button2;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private DateTimePicker dateTimePicker1;
        private Label label5;
        private Button button1;
    }
}